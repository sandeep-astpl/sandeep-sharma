Thank you so much for purchasing Envision.

*   Installation:

    1) 	WordPress Upload Method: Upload the "envision.zip" file 
        via "WP Admin > Appearance > Add New Themes > Upload" page to install the theme. 

    2)	FTP Upload: Unzip the "envision.zip" file and using a FTP client software
        upload the unzipped theme folder into the /wp-content/themes/ folder on your server.

    You can find more details about installing in the documentation.

**  Documentation: Please read the theme documentation before installing. (in /documentation/ folder)

*** Resources: You can find importable zip files of predefined visual sets(skins) and sample sliders in "/resource/" folder.

Enjoy it!