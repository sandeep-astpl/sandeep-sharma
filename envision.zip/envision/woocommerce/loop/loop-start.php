<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */
global $woocommerce_loop_output;
       $woocommerce_loop_output = ''; 
?>
<div class="clearfix"></div>
<div class="products clearfix">