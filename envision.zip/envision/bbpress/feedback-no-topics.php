<?php

/**
 * No Topics Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="bbp-template-notice">
	<p><?php _e( 'Oh bother! No topics were found here!', 'bbpress' ); ?></p>
</div>
