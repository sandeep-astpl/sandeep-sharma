<?php
/**
 *	Register Slider
 *
 *	@package CloudFw
 *	@since 	 1.0
 */

cloudfw_register_slider( 'flex_slider', 'CloudFw_Flex_Slider', __('Flex Slider','cloudfw') );