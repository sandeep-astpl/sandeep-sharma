<?php 

if ( !is_admin() )
    require( trailingslashit(dirname(__FILE__)) . 'primary-navigation.php' );