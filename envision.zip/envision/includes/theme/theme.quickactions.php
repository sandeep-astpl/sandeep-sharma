<?php
/**
 *	Quick Actions
 *
 *	@package WordPress
 *	@subpackage CloudFW
 */