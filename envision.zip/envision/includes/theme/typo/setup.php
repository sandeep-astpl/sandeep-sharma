<?php

/** Web Fonts */
/*$map  -> id  ( 'body' )
      -> sub ( 'font-family', 'Helvetica, Arial, sans-serif' );*/

$map  -> id  ( 'headings' )
      -> sub ( 'font-family', 'Roboto' );