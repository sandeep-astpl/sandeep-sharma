<?php
/**
 *	Portfolio Filter Archives
 *
 *	@since 1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

return cloudfw( 'return_layout', 'taxonomy-portfolio-category.php' );