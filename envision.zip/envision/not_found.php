<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?><article class="entry">
        <h1 class='post-title entry-title'><?php echo cloudfw_translate( 'nothing_found' ); ?></h1>
    </header>

    <p class="entry-content"><?php echo cloudfw_translate( 'no_posts_matched' ); ?></p>

	<div class="text-left" style="width:100%; margin: auto;"><?php get_search_form(); ?></div>
	<div class="down"></div>


</article>