<?php

if (file_exists( TMP_PATH.'/cloudfw/core/others/source.system.php' )):
	include_once(TMP_PATH.'/cloudfw/core/others/source.system.php');
	cloudfw_get_form_import_skin();
endif;