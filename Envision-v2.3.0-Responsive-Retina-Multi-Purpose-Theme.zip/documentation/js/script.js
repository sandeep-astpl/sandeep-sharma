
jQuery(function($){

	$('#toc a, a.go').click(function(){
		$.scrollTo( this.hash, 1000, { offset: { top:-50 } });
		return false;
	});	

	$('.goto').click(function(){
		var that 	= jQuery(this),
			to 		= that.attr('data-to'); 

		$.scrollTo( '#' + to, 1000, { offset: { top:-50 } });
		return false;
	});	

	window.prettyPrint && prettyPrint();

});